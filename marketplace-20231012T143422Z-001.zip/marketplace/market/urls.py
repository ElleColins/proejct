from django.urls import path
from . import views

urlpatterns = [
    path('', views.login, name='market-login'),
    path('fashion/', views.fashion, name='market-fashion'),
    path('appliances/', views.appliances, name='market-appliances'),
    path('gadgets/', views.gadgets, name='market-gadgets'),
    path('home/', views.home, name='market-home'),
]