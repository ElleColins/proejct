from django.shortcuts import render
# Create your views here.

def gadgets (request):
    return render(request, 'market/gadgets.html')

def fashion (request):
    return render(request, 'market/fashion.html')

def home (request):
    return render(request, 'market/home.html')

def appliances (request):
    return render(request, 'market/appliances.html')

def login (request):
    return render(request, 'market/login.html')